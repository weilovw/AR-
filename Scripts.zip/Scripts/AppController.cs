﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GoogleARCore;
using GoogleARCore.Examples.Common;
using UnityEngine.SceneManagement;

public class AppController : MonoBehaviour {
    private bool mIsQuitting = false;
    public Camera FirstPersonCamera;
    public GameObject prefab;
    private const float mModelRotation = 180.0f;
    GameObject you;
    /*public GameObject DetectedPlanePrefab;
    private List<DetectedPlane> mNewPlanes = new List<DetectedPlane>();
    private List<DetectedPlane> mAllPlanes = new List<DetectedPlane>();*/
    // Use this for initialization
    void Start () {
        
    OnCheckDevice();
    }

    // Update is called once per frame
    void Update () {
        UpdateApplicationLifecycle();
        /*Session.GetTrackables<DetectedPlane>(mNewPlanes, TrackableQueryFilter.New);
        for (int i = 0; i < mNewPlanes.Count; i++)
        {
            GameObject planeObject = Instantiate(DetectedPlanePrefab, Vector3.zero, Quaternion.identity,
                transform);
            planeObject.GetComponent<DetectedPlaneVisualizer>().Initialize(mNewPlanes[i]);
        }

        Session.GetTrackables<DetectedPlane>(mAllPlanes);*/


        //Touch touch;
        if (Input.touchCount < 1 || ( Input.GetTouch(0)).phase != TouchPhase.Began)
        {
            return;
        }

        TrackableHit hit;
        TrackableHitFlags raycastFilter = TrackableHitFlags.PlaneWithinPolygon | TrackableHitFlags.PlaneWithinBounds;

        if (Frame.Raycast(Input.GetTouch(0).position.x, Input.GetTouch(0).position.y, raycastFilter, out hit))
        {
            if ((hit.Trackable is DetectedPlane) && Vector3.Dot(FirstPersonCamera.transform.position - hit.Pose.position, hit.Pose.rotation * Vector3.up) < 0)
            {
                Debug.Log("射线击中了DetectedPlane的背面！");
            }
            else
            {
                if (you==null)
                {
                    you = Instantiate(prefab, hit.Pose.position, hit.Pose.rotation,transform);
                    var anchor = hit.Trackable.CreateAnchor(hit.Pose);
                    you.transform.parent = anchor.transform;
                    you.transform.Rotate(Vector3.up,180,Space.Self);

                }
                else
                {
                    Debug.Log("Only One");
                }
               
            }
        }
    }
    /// <summary>
    /// 检查设备
    /// </summary>
    private void OnCheckDevice()
    {
        if (Session.Status == SessionStatus.ErrorSessionConfigurationNotSupported)
        {
            ShowAndroidToastMessage("ARCore不受支持或配置错误！你没办法使用小天使噢，快去买新手机吧~");
            mIsQuitting = true;
            Invoke("DoQuit", 0.5f);
        }
        else if (Session.Status == SessionStatus.ErrorPermissionNotGranted)
        {
            ShowAndroidToastMessage("AR应用的运行需要使用摄像头，现无法获取到摄像头授权信息，请允许使用摄像头！");
            mIsQuitting = true;
            Invoke("DoQuit", 0.5f);
        }
        else if (Session.Status.IsError())
        {
            ShowAndroidToastMessage("ARCore运行时出现错误，请重新启动本程序！");
            mIsQuitting = true;
            Invoke("DoQuit", 0.5f);
        }
    }
    /// <summary>
    /// 弹出信息提示
    /// </summary>
    /// <param name="message">要弹出的信息</param>
    private void ShowAndroidToastMessage(string message)
    {
        AndroidJavaClass unityPlayer = new AndroidJavaClass("com.unity3d.player.UnityPlayer");
        AndroidJavaObject unityActivity = unityPlayer.GetStatic<AndroidJavaObject>("currentActivity");
        if (unityActivity != null)
        {
            AndroidJavaClass toastClass = new AndroidJavaClass("android.widget.Toast");
            unityActivity.Call("runOnUiThread", new AndroidJavaRunnable(() =>
            {
                AndroidJavaObject toastObject = toastClass.CallStatic<AndroidJavaObject>("makeText", unityActivity, message, 0);
                toastObject.Call("show");
            }));
        }
    }
    /// <summary>
    /// 退出程序
    /// </summary>
    private void DoQuit()
    {
        Application.Quit();
    }
    /// <summary>
    /// 管理应用的生命周期
    /// </summary>
    private void UpdateApplicationLifecycle()
    {
        if (Session.Status != SessionStatus.Tracking)
        {
            const int lostTrackingSleepTimeout = 15;
            Screen.sleepTimeout = lostTrackingSleepTimeout;
        }
        else
        {
            Screen.sleepTimeout = SleepTimeout.NeverSleep;
        }

        if (mIsQuitting)
        {
            return;
        }
    }
}
