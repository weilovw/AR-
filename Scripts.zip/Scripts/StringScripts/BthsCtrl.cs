﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class BthsCtrl : MonoBehaviour {
    Button textBth;
    Button enterBth;
    Button rightBth;
    Button wrongBth;
    Button helpBth;
    public Canvas mapCanvas;
	// Use this for initialization
	void Start () {
        Init();
    }

    //初始化
    void Init()
    {
        textBth = transform.Find("TextBth").GetComponent<Button>();
        enterBth = transform.GetChild(0).Find("EnterBth").GetComponent<Button>();
        rightBth = transform.Find("RightBth").GetComponent<Button>();
        wrongBth = transform.Find("WrongBth").GetComponent<Button>();
        helpBth = transform.Find("HelpBth").GetComponent<Button>();
        textBth.onClick.AddListener(() => { OthersMove.Instance.InputMove(true); });
        enterBth.onClick.AddListener(() => { InputString.Instance.Enter(); });
        enterBth.onClick.AddListener(() => { OthersMove.Instance.InputMove(false); });
        rightBth.onClick.AddListener(() => { OthersMove.Instance.RLMove(false); });
        wrongBth.onClick.AddListener(() => { OthersMove.Instance.RLMove(false); });
        helpBth.onClick.AddListener(ShowMapCanvas);
        helpBth.onClick.AddListener(() => { MapMoveCtrl.Instance.GoBack(); });
    }

    void ShowMapCanvas()
    {
        mapCanvas.enabled = true;
    }
}
