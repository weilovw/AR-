﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using UnityEngine.EventSystems;

public class OthersMove : Singleton<OthersMove> {
    Image inputIma;
    Image inputFieldIma;
    Image enterIma;
    public float inputImaFadeTime;
    public float inputImaShowTime;
    Image rightIma;
    Image wrongIma;
    public float rWImaFadeTime;
    public float rWImaShowTime;
    public bool ifInputShow1;
    public bool ifInputShow2;
    // Use this for initialization
    void Start() {
        Init();
    }

    void Update()
    {
        if (ifInputShow1)
        {
            // if (EventSystem.current.currentSelectedGameObject.GetComponent<InputField>() != null)
            if (InputString.Instance.input.isFocused)
            {
                ifInputShow2 = false;
            }
            else if (InputString.Instance.input.text==null)
            {
                ifInputShow2 = true;
            }
        }
       
#if UNITY_EDITOR
        Invoke("GoUp", 1f);

#elif UNITY_ANDROID
        Invoke("GoUpAndroid", 1f);
#endif

    }
    void Init()
    {
        inputIma = transform.Find("InputBG").GetComponent<Image>();
        inputFieldIma = inputIma.transform.Find("InputField").GetComponent<Image>();
        enterIma = inputIma.transform.Find("EnterBth").GetComponent<Image>();
        rightIma = transform.Find("RightBth").GetComponent<Image>();
        wrongIma = transform.Find("WrongBth").GetComponent<Image>();
        rightIma.gameObject.SetActive(false);
        wrongIma.gameObject.SetActive(false);
    }

    //文字输入框显示消失
    public void InputMove(bool isShow)
    {
        if (isShow)
        {
            inputIma.DOFade(255, inputImaFadeTime).SetEase(Ease.Flash).SetAutoKill(false);
            inputFieldIma.DOFade(255, inputImaFadeTime).SetEase(Ease.Flash).SetAutoKill(false);
            enterIma.DOFade(255, inputImaFadeTime).SetEase(Ease.Flash).SetAutoKill(false);
            inputIma.transform.DOLocalMoveY(1030,inputImaShowTime).SetEase(Ease.Linear).SetAutoKill(false);
            ifInputShow1 = true;
            ifInputShow2 = true;
        }
        else
        {
            inputIma.DOPlayBackwards();
            inputFieldIma.DOPlayBackwards();
            enterIma.DOPlayBackwards();
            inputIma.transform.DOPlayBackwards();
            StartCoroutine(InputGoUp(0.6f));
            ifInputShow1 = false;
            ifInputShow2 = false;
        }
    }

    //对错显示消失
    public void RLMove(bool isShow)
    {
        if (isShow)
        {
            StartCoroutine(SetActive(0, true));
            rightIma.DOFade(255, inputImaFadeTime).SetEase(Ease.Flash).SetAutoKill(false);
            rightIma.transform.DOLocalMoveX(-470, inputImaShowTime).SetEase(Ease.Linear).SetAutoKill(false);
            wrongIma.DOFade(255, inputImaFadeTime).SetEase(Ease.Flash).SetAutoKill(false);
            wrongIma.transform.DOLocalMoveX(470, inputImaShowTime).SetEase(Ease.Linear).SetAutoKill(false);
        }
        else
        {
            rightIma.DOPlayBackwards();
            rightIma.transform.DOPlayBackwards();
            wrongIma.DOPlayBackwards();
            wrongIma.transform.DOPlayBackwards();
            StartCoroutine(SetActive(rWImaFadeTime, false));
        }
    }

    IEnumerator SetActive(float time, bool isActive)
    {
        yield return new WaitForSeconds(time);
        rightIma.gameObject.SetActive(isActive);
        wrongIma.gameObject.SetActive(isActive);
    }

    

    void GoUp()
    {
        if (ifInputShow2)
        {
            if (Input.GetMouseButtonUp(0)) InputMove(false);
        }
    }

    void GoUpAndroid()
    {
        if (ifInputShow2)
        {
            if (Input.GetTouch(0).phase == TouchPhase.Ended) InputMove(false);
        }
    }

    //如果动画没有倒播完毕设置为初始位置
    IEnumerator InputGoUp(float time)
    {
        yield return new WaitForSeconds(time);
        if (inputIma.transform.position.y<150)
        {
            inputIma.transform.position =new Vector2(inputIma.transform.position.x, 150);
        }
    }
}
