﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JudgeString : Singleton<JudgeString> {
    [Tooltip("关键字")]
    [SerializeField]
    List<string> keyStrings;
    public AudioClip[] allAudioClips;
    public int[] haveLocations;
    int locationsLength;
    AudioSource myAudioSource;
    int listLength;
    bool isGoShowRW;
   
    // Use this for initialization
    void Start () {
        myAudioSource = GetComponent<AudioSource>();
        locationsLength = haveLocations.Length;
        Init();
    }

    void Init()
    {
        keyStrings = new List<string>();
        keyStrings.Add("篮球");
        keyStrings.Add("767");
        keyStrings.Add("校车");
        keyStrings.Add("游泳");
        keyStrings.Add("在读证明");
        keyStrings.Add("网球");
        keyStrings.Add("补办");
        keyStrings.Add("挂失");
        keyStrings.Add("还款");
        keyStrings.Add("食堂");
        keyStrings.Add("校医院位置");
        keyStrings.Add("校医院开放时间");
        keyStrings.Add("健身");
        keyStrings.Add("校园网");
        keyStrings.Add("晨跑起点");
        keyStrings.Add("晨跑时间");
        keyStrings.Add("自习室位置");
        keyStrings.Add("自习室开放时间");
        keyStrings.Add("护照");
        keyStrings.Add("机房");
        listLength = keyStrings.Count;
    }

   void Update()
    {
        if (isGoShowRW)
        {
            ShowRW();
        }
    }

    //判断是哪一个问题
    public void JudgeWhich(string whichString)
    {
        for (int i = 0; i < listLength; i++)
        {
            if (whichString.Contains(keyStrings[i]))
            {
                if (myAudioSource.isPlaying)
                {
                    myAudioSource.Stop();
                }
                myAudioSource.PlayOneShot(allAudioClips[i]);

                for (int j = 0; j < locationsLength; j++)
                {
                    if (i == haveLocations[j])
                    {
                        isGoShowRW = true;
                    }
                }
                return;
            }
        }
        PlayINo();
    }

    //不知道
    public void PlayINo()
    {
        if (myAudioSource.isPlaying)
        {
            myAudioSource.Stop();
        }
        myAudioSource.PlayOneShot(allAudioClips[20]);
    }

    //判断何时出现对错
    void ShowRW()
    {
        if (!myAudioSource.isPlaying)
        {
            OthersMove.Instance.RLMove(true);
            isGoShowRW = false;
        }
    }


    
    // 播放去或者不去
    public void PlayGo(bool isGo)
    {
        if (myAudioSource.isPlaying)
        {
            myAudioSource.Stop();
        }

        if (isGo)
        {
            myAudioSource.PlayOneShot(allAudioClips[21]);  
        }
        else
        {
            myAudioSource.PlayOneShot(allAudioClips[22]);
        }
       
    }
}
