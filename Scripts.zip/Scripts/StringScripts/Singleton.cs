﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//泛型单例
public class Singleton<T> : MonoBehaviour where T : Singleton<T>
{
    private static T _instance;
    public static T Instance
    {
        get
        {
            return _instance;
        }
    }

    protected virtual void Awake()
    {
        if (_instance==null)
        {
            _instance = (T)this;
        }
    }

    protected virtual void OnDestroy()
    {
        if (_instance==this)
        {
            _instance = null;
        }
    }

    
}
