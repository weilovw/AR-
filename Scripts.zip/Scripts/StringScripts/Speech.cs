﻿using UnityEngine;
using UnityEngine.UI;
using BaiduAip;

public class Speech : MonoBehaviour
{
    public string APIKey = "";
    public string SecretKey = "";
   
    private AudioClip _clipRecord;
    private AudioR _asr;

    // Microphone is not supported in Webgl
#if !UNITY_WEBGL

    void Start()
    {
        _asr = new AudioR(APIKey, SecretKey);
        StartCoroutine(_asr.GetAccessToken());
    }

    public  void OnClickStartButton()
    {
        _clipRecord = Microphone.Start(null, false, 30, 16000);
    }

    public void OnClickStopButton()
    {
        Microphone.End(null);
        Debug.Log("开始识别已输入的语音");
        var data = AudioR.ConvertAudioClipToPCM16(_clipRecord);
        StartCoroutine(_asr.Recognize(data, s =>
        {
            if (s.result != null && s.result.Length > 0)
            {
                JudgeString.Instance.JudgeWhich(s.result[0]);
            }
            else 
            {
                JudgeString.Instance.PlayINo();
            }
        }));
    }
#endif
}