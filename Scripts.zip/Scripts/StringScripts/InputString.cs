﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class InputString : Singleton<InputString> {
    public  InputField input;

	// Use this for initialization
	void Start () {
        input = GetComponent<InputField>();
      
	}

    public  void Enter()
    {
        if (input.text==null)
        {
            JudgeString.Instance.PlayINo();
        }
        else
        {
            JudgeString.Instance.JudgeWhich(input.text);
        }
        input.text = null;
       
    }
}
