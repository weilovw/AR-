﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//move can not see blank
public class MapMoveCtrl:Singleton<MapMoveCtrl> {

    #region x,y and others
 public  RectTransform imageRTS;
 public  Vector2 initMapPos;
 public  Vector2 initMapScale;
    int X;
    int Y;
    int maxX;
    int minX;
    int maxY;
    int minY;
    int halfImageWidth;
    int halfImageHeight;
    int halfScreenWidth;
    int halfScreenHeight;
    #endregion

    // Use this for initialization
    void Start () {
        imageRTS = GetComponent<RectTransform>();
        initMapPos = imageRTS.localPosition;
        initMapScale = imageRTS.localScale;
        //防止到地图最边缘
        halfScreenWidth =(int)(Screen.width * 0.5f+10);
        halfScreenHeight =(int)(Screen.height * 0.5f+10);
        GetImageWH();
        GetttFourPos();
        Debug.Log(maxX);
    }

 
    //当地图大小改变时获取地图的长和宽
 public void GetImageWH()
    {
        halfImageWidth = Mathf.RoundToInt(imageRTS.rect.width * imageRTS.localScale.x*0.5f);
        halfImageHeight =Mathf.RoundToInt(imageRTS.rect.height * imageRTS.localScale.y*0.5f);  
    }

    //当地图大小改变时获取地图x和y极限值
    public void GetttFourPos()
    {
        maxX = halfImageWidth-halfScreenWidth;
        minX = halfScreenWidth- halfImageWidth;
        maxY = halfImageHeight-halfScreenHeight;
        minY = halfScreenHeight - halfImageHeight;
    }
    //获取实时四个位置的值
    public  void GetXYPos()
    {
        X = Mathf.RoundToInt(imageRTS.localPosition.x);
        Y = Mathf.RoundToInt(imageRTS.localPosition.y) ;
   
    }

    //限制地图移动范围
  public  void Clamp()
    {
        if (X<=minX)
        {
            ClampPos(0,minX);
        }
        else if (X>=maxX)
        {
            ClampPos(0,maxX);
        }


        if (Y<=minY)
        {
            ClampPos(1, minY);
        }
        else if (Y >= maxY)
        {
            ClampPos(1, maxY);
        }
    }

    //改变地图坐标
   void ClampPos(int which, float changed)
    {
        if (which == 0)
        {
            imageRTS.localPosition = new Vector2(changed, imageRTS.localPosition.y);
        }
        else
        {
            imageRTS.localPosition = new Vector2(imageRTS.localPosition.x,changed);
        }
    }

    //地图回到初始值
    public void GoBack()
    {
        if (imageRTS.localScale.x != initMapScale.x)
        {
            imageRTS.localScale = initMapScale;
        }
        if (new Vector2(imageRTS.localPosition.x, imageRTS.localPosition.y) != initMapPos)
        {
            imageRTS.localPosition = initMapPos;
        }
    }
}
