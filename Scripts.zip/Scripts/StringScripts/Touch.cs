﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Touch : MonoBehaviour {
    RectTransform imageRTS;
    Vector3 awayDistance;
    public  bool isGo;
    Vector2 oldPos1;
    Vector2 oldPos2;
    public float onceScale;
    public float biggestScale;
    public float smallestScale;
	// Use this for initialization
	void Start () {
        imageRTS =GetComponent<RectTransform>();
	}

    // Update is called once per frame
    void Update()
    {
#if UNITY_EDITOR
        ImageMove();

# elif UNITY_ANDROID
        if (Input.touchCount == 1)
        {
            ImageMove();
        }

        if (Input.touchCount == 2)
        {
            if (Input.GetTouch(0).phase == TouchPhase.Moved && Input.GetTouch(1).phase == TouchPhase.Moved)
            {
                Vector2 temPos1 = Input.GetTouch(0).position;
                Vector2 temPos2 = Input.GetTouch(1).position;
                int temp = IsEnlarge(oldPos1, oldPos2, temPos1, temPos2);

                if (temp == 1&& imageRTS.localScale.x<biggestScale)
                {
                    float oldScale = transform.localScale.x;
                    float newScale = oldScale * onceScale;
                    imageRTS.localScale = new Vector3(newScale, newScale, newScale);
                    MapMoveCtrl.Instance.GetImageWH();
                    MapMoveCtrl.Instance.GetttFourPos();
                 
                }
                else if (temp==2&&imageRTS.localScale.x>smallestScale)
                {
                    float oldScale = transform.localScale.x;
                    float newScale = oldScale / onceScale;
                    imageRTS.localScale = new Vector3(newScale,newScale,newScale);
                    MapMoveCtrl.Instance.GetImageWH();
                    MapMoveCtrl.Instance.GetttFourPos();
                }
                else if (temp==0)
                {
                    ImageMove();
                }
                oldPos1 = temPos1;
                oldPos2 = temPos2;
            }
        }
#endif
    }

    //判断放大还是缩小
        int IsEnlarge(Vector2 op1,Vector2 op2,Vector2 np1,Vector2 np2)
        {
            //Mathf.Sqrt平方根 ,Mathf.Pow次方
            float length1 = Mathf.Sqrt(Mathf.Pow(op1.x-op2.x,2)+Mathf.Pow(op1.y-op2.y,2));
            float length2 = Mathf.Sqrt(Mathf.Pow(np1.x-np2.x,2)+Mathf.Pow(np1.y-np2.y,2));
            if (length1<length2)
            {
                return 1;
            }
            else if (length1>length2)
            {
                return 2;
            }
            else
            {
                return 0;
            }
        }

    void ImageMove()
    {
        
        if (Input.GetMouseButtonDown(0))
        {
            awayDistance = imageRTS.position - Input.mousePosition;
            isGo = true;
        }
        if (Input.GetMouseButton(0) && isGo)
        {
            imageRTS.position = awayDistance + Input.mousePosition;
            MapMoveCtrl.Instance.GetXYPos();
            MapMoveCtrl.Instance.Clamp();
        }
        if (Input.GetMouseButtonUp(0))
        {
            isGo = false;
        }

        //if (Input.GetTouch(0).phase == TouchPhase.Began)
        //{
        //    awayDistance = imageTrs.localPosition - Input.mousePosition;
        //    isGo = true;
        //}
        //else if (Input.GetTouch(0).phase == TouchPhase.Moved && isGo)
        //{
        //    imageTrs.localPosition = awayDistance + Input.mousePosition;
        //}
        //else if (Input.GetTouch(0).phase == TouchPhase.Ended)
        //{
        //    isGo = false;
        //}
    }

    }

